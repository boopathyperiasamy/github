package com.cs.algo.algoweb.controller;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cs.algo.algoweb.CacheContainer;

@Controller
@RequestMapping("/instrumentalerts")
public class InstrumentAlerts {

	@Autowired
	private ServletContext servletContext;

	@RequestMapping(method = RequestMethod.GET)
	public String home(Model model) {

		CacheContainer appData = (CacheContainer) servletContext.getAttribute("CacheContainer");
		model.addAttribute("strategyList", appData.getStrategies());
		return "instrumentalerts";
	}
}
