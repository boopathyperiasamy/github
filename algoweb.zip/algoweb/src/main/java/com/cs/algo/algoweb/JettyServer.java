package com.cs.algo.algoweb;

import java.io.File;
import java.net.URL;

import javax.servlet.ServletContext;

import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * @author Stas
 * @date 4/1/13
 */
public class JettyServer implements ApplicationContextAware {

	public static final String WEB_APP_ROOT = "webapp"; // that folder has to be
														// just somewhere in
														// classpath
	public static final String MVC_SERVLET_NAME = "mvcDispatcher";
	public static final String JSP_SERVLET_NAME = "jspServlet";

	private final int port;

	private Server server;

	private ApplicationContext appContext;
	private CacheContainer cacheContainer;
	private Authenticator authenticator;

	public JettyServer(int port, CacheContainer appData, Authenticator authenticator) {
		this.port = port;
		this.cacheContainer = appData;
		this.authenticator = authenticator;
	}

	public void preStart() {

		server = new Server(port);
		server.setHandler(getServletHandler());

	}

	private ServletContextHandler getServletHandler() {
		ServletHolder mvcServletHolder = new ServletHolder(MVC_SERVLET_NAME, new DispatcherServlet());
		mvcServletHolder.setInitParameter("contextConfigLocation", "web-context.xml");

		ServletHolder jspServletHolder = new ServletHolder(JSP_SERVLET_NAME, new org.apache.jasper.servlet.JspServlet());
		// these two lines are not strictly required - they will keep classes
		// generated from JSP in
		// "${javax.servlet.context.tempdir}/views/generated"
		jspServletHolder.setInitParameter("keepgenerated", "true");
		jspServletHolder.setInitParameter("scratchDir", "views/generated");

		// session has to be set, otherwise Jasper won't work
		ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
		context.setAttribute("javax.servlet.context.tempdir", new File("../tmp/webapp"));
		// that classloader is requres to set JSP classpath. Without it you will
		// just get NPE
		context.setClassLoader(Thread.currentThread().getContextClassLoader());
		context.addServlet(jspServletHolder, "*.jsp");
		context.addServlet(mvcServletHolder, "/");
		context.setResourceBase(getBaseUrl());

		return context;
	}

	public void join() throws InterruptedException {
		server.join();
	}

	public void startServer() {

		preStart();

		try {
			ServletContext servletContext = null;

			System.out.println("Main spring context " + appContext);

			System.out.println("Searching for servlet context...");
			for (Handler handler : server.getHandlers()) {
				System.out.println("Found handler context..." + handler);
				if (handler instanceof ServletContextHandler) {
					servletContext = ((ServletContextHandler) handler).getServletContext();
				}
			}
			servletContext.setAttribute("CacheContainer", cacheContainer);
			servletContext.setAttribute("Authenticator", authenticator);

			// if (servletContext != null) {
			// System.out.println("Setting the bridge context");
			// XmlWebApplicationContext wctx = new XmlWebApplicationContext();
			// wctx.setParent(appContext);
			// wctx.setConfigLocation("");
			// wctx.setServletContext(servletContext);
			// wctx.refresh();
			// servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE,
			// wctx);
			// }

			server.start();

			this.join();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getBaseUrl() {
		URL webInfUrl = JettyServer.class.getClassLoader().getResource(WEB_APP_ROOT);
		if (webInfUrl == null) {
			throw new RuntimeException("Failed to find web application root: " + WEB_APP_ROOT);
		}

		return webInfUrl.toExternalForm();
	}

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		appContext = applicationContext;

	}
}