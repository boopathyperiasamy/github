package com.cs.algo.algoweb;

import java.util.ArrayList;
import java.util.List;

public class CacheContainer {

	private String appName;

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public List<String> getStrategies() {
		List<String> list = new ArrayList<String>();
		list.add("MovingAverage");
		list.add("HighVolatile");

		return list;
	}

}
