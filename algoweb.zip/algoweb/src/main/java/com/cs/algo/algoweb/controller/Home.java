package com.cs.algo.algoweb.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cs.algo.algoweb.Authenticator;

@Controller
@RequestMapping("home")
public class Home {

	@Autowired
	private ServletContext servletContext;

	@RequestMapping(method = RequestMethod.GET)
	public String getHome() {
		System.out.println("Returning home....");
		System.out.println(servletContext.getAttribute("CacheContainer"));
		return "home";
	}

	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String userLogin(@ModelAttribute("username") String username, @ModelAttribute("password") String password,
			HttpServletRequest request, RedirectAttributes ra) {

		boolean isAuthenticated = false;
		try {
			System.out.println("Authenticating user :" + username + " password:" + password);
			Authenticator authenticator = (Authenticator) servletContext.getAttribute("Authenticator");
			isAuthenticated = authenticator.login(username, password);
		} catch (Exception e) {
			System.out.println("Error authenticating user..." + e);
		}
		isAuthenticated = true;
		request.getSession().setAttribute("isAuthenticated", isAuthenticated);

		return "redirect:/home";
	}

}
