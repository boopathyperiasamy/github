package com.cs.algo.algoweb;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ServerMain {
	public static void main(String args[]) throws Exception {
		try {

			ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
					new String[] { "spring-all.xml" });
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
