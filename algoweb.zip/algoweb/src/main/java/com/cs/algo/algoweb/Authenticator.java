package com.cs.algo.algoweb;

import org.springframework.ldap.core.DistinguishedName;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;

public class Authenticator {

	private LdapTemplate ldapTemplate;

	public Authenticator(LdapTemplate ldapTempate) {
		this.ldapTemplate = ldapTempate;
	}

	public boolean login(String username, String password) {
		AndFilter filter = new AndFilter();
		filter.and(new EqualsFilter("objectclass", "person")).and(new EqualsFilter("cn", username));
		return ldapTemplate.authenticate(DistinguishedName.EMPTY_PATH, filter.toString(), password);
	}
}
